import './App.css';
import PersonCard from './components/PersonCard';

function App() {
  return (
    <div>
      <PersonCard 
        firstName = {"Nobara"}
        lastName = {"Kugasaki"}
        age = {16}
        hairColor = {"Red"}
      />
      <PersonCard 
        firstName = {"Satoru"}
        lastName = {"Gojo"}
        age = {28}
        hairColor = {"White"}
      />
      <PersonCard 
        firstName = {"Yuta"}
        lastName = {"Okkotsu"}
        age = {17}
        hairColor = {"Black"}
      />
      <PersonCard 
        firstName = {"Mai"}
        lastName = {"Zenin"}
        age = {17}
        hairColor = {"Black"}
      />
    </div>
  );
}

export default App;
